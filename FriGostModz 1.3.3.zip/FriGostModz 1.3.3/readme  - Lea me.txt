1 - open the GTA5.

2 - open the injector as administrator.

3 - if you are not authenticated, insert your key.

4 - after that wait for the message Dll Sucessful Injected, and the injector will automatically close.

5- Add FrigostRedist disk local C

6- Main Menu > Settings > Languages

7- TUTORIAL: https://youtu.be/72QAiXQPeeU


Keyboard

Open: F8
Select: 5
Up: 8
Down: 2
Back: 0
Left: 4
Right: 6

Joystick

Open: RB + Right
Back: O
Move: D-pad


Website: https://frigoststore.com.br/
https://discord.gg/w8g5v6QBMy